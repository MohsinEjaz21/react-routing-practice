import About from "./About";
import Home from "./Home";
import Navbar from "./Navbar";

export { Home, About, Navbar };

